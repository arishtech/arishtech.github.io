<?php 
add_action( 'init', 'restly_custom_post_type' );
function restly_custom_post_type() {
    register_post_type( 'restly_portfolio',
        array(
            'labels' => array(
                'name' => esc_html__('Portfolio','restlycore'),
                'singular_name' => esc_html__('Portfolio','restlycore'),
            ),
            'show_in_rest'  => true,
            'supports'      => array('title','thumbnail', 'page-attributes','editor','excerpt'),
            'menu_icon'     => esc_attr__('dashicons-image-filter','restlycore'),
            'public'        => true,
            'rewrite'               => array(
                'slug'              => 'restly-portfolio', 
                'with_front'        => true 
            )
        )
    );
    register_post_type( 'restly_team',
        array(
            'labels' => array(
                'name' => esc_html__('Team','restlycore'),
                'singular_name' => esc_html__('Team','restlycore'),
            ),
            'show_in_rest'  => true,
            'supports'      => array('title','thumbnail', 'page-attributes','editor','excerpt'),
            'menu_icon'     => esc_attr__('dashicons-admin-users','restlycore'),
            'public'        => true,
            'rewrite'               => array(
                'slug'              => 'restly-team', 
                'with_front'        => true 
            )
        )
    );
}
/*** Custom taxonomy ***/
add_action( 'init', 'restly_custom_post_taxonomy');
function restly_custom_post_taxonomy() {
    register_taxonomy(
        'restly_portfolio_cat',
        'restly_portfolio',                  
            array(
                'label'                 => esc_html__('Portfolio Category', 'restlycore'),
                'query_var'             => true,
                'hierarchical'          => true,
                'public'                => true,
                'show_ui'               => true,
                'show_admin_column'     => false,
                'show_in_nav_menus'     => true,
                'show_in_rest'          => true,
                'show_tagcloud'         => true,
                'rewrite'               => array(
                    'slug'              => 'portfolio-category', 
                    'with_front'        => true 
                )
            )
    );
}