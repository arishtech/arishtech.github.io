<?php


if (!defined('ABSPATH')) exit; // No access of directly access


class restlyElementorWidget {

    private static $instance = null;

    public static function get_instance() {
        if (!self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    public function init() {
        add_action('elementor/widgets/widgets_registered', array($this, 'restly_elementor_widgets'));
    }

    public function restly_elementor_widgets() {

        // Check if the Elementor plugin has been installed / activated.
        if (defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')) {

            require_once('title.php');
            require_once('home-banner.php');
            require_once('service-box.php');
            require_once('image.php');
            require_once('about-us.php');
            require_once('counter.php');
            require_once('theme-button.php');
            require_once('work-process.php');
            require_once('pricing-table.php');
            require_once('portfolio-info.php');
            require_once('contact-info.php');
            require_once('home-portfolio.php');
            require_once('home-blog.php');
            require_once('feature-icon-with-title.php');
            require_once('clients-logo.php');
            require_once('team-title.php');
            require_once('team-member.php');
            require_once('mailchip-subscribe.php');
            require_once('our-testimonial.php');
            require_once('portfolio-category.php');
            require_once('contact-info-box.php');
            require_once('dot-shape.php');
            require_once('shape.php');
            require_once('social-icons.php');
            require_once('line.php');
        }
    }
}

restlyElementorWidget::get_instance()->init();


function restly_elementor_widget_categories($elements_manager) {

    $elements_manager->add_category(
        'restly',
        [
            'title' => __('Restly Elements', 'restlycore'),
        ]
    );

}

add_action('elementor/elements/categories_registered', 'restly_elementor_widget_categories');